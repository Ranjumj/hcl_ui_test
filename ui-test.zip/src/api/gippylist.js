
import handleHttpRequest from './httprequest';

const BASE_URL = 'http://api.giphy.com/v1/gifs/';
const API_KEY = '7XON9hiSSpzbOGJngdbw6186UmFDuha9';

async function getTrendingGipphy(offset,perPage) {
    const url = `${BASE_URL}trending?api_key=${API_KEY}&limit=${perPage}&offset=${offset}`;
    return await handleHttpRequest('GET',url);
}

export async function getSearchedGipphy(searchVal,offset,perPage) {
    const url = `${BASE_URL}search?api_key=${API_KEY}&q=${searchVal}&limit=${perPage}&offset=${offset}`;
    return await handleHttpRequest('GET',url);
}

export default getTrendingGipphy;

