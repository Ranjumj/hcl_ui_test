import axios from 'axios';

const GET = 'GET';

async function handleHttpRequest(method,url,headers= {},){
    let response = '';
    if(method === GET){
        response = await axios.get(url);
    }

    if(response.status === 200){
        return response.data;
    }else{
        return {error: response};
        }
    }

export default handleHttpRequest;

