import React, { Component } from 'react';

class ThumbnailGrid extends Component {

    constructor(props){
        super(props);
    }

    playGif = (gif,still) => event =>{
       this.props.playGif(gif, still);
       event.preventDefault();
    }

    render(){
        return (
         <div >
             {this.props.data.map((val,key) =>
             <div  key={key} className={'thubnail-grid'} onClick={this.playGif(val.images.original.url,val.images.original_still.url)}><img width="200px" height="200px" src={val.images.original_still.url}></img></div> )}
         </div>
        );
    }
}

export default ThumbnailGrid;