import React, { Component } from 'react';
import ThumbnailGrid from './thumbnailgrid';
import ReactPaginate from 'react-paginate';
import getTrendingGipphy, {getSearchedGipphy} from '../api/gippylist';


class Home extends Component {

    constructor(props){
        super(props);
        this.state = {
            data:[],
            offset:0,
            serachValue : '',
            pageCount: 0,
            perPage:24,
            isSearching: false,
            playGif: false,
            gifImageUrl:null,
            previewUrl:null,
        }
    }

    async componentDidMount(){
        await this.trendingGif();
      }

    handleSearchSubmit  = async event => {
        this.setState({offset:0,pageCount: 0,isSearching:true}, async ()=>{
           await this.searchgGif();
        });
        event.preventDefault();
    }

    handleSearchValueChange = event => {
        this.setState({serachValue: event.target.value,}, async ()=> {
            if(!this.state.serachValue){
                this.setState({isSearching:false}, async()=>{
                    await this.trendingGif();
                })
            }
        });
    }


    trendingGif = async ()  => {
        const result = await  getTrendingGipphy(this.state.offset, this.state.perPage);
        this.setState({data:result.data,pageCount:Math.ceil(result.pagination.total_count / result.pagination.count)})
       }

    searchgGif = async ()  => {
        const result =  await  getSearchedGipphy(this.state.serachValue, this.state.offset, this.state.perPage);
        this.setState({data:result.data,pageCount:Math.ceil(result.pagination.total_count / result.pagination.count)})
        }


   
    handlePageClick = data => {
        let selected = data.selected;
        let offset = Math.ceil(selected * this.state.perPage);
        window.scrollTo(0,0);
        this.setState({ offset: offset }, async() => {
            this.state.isSearching ? await this.searchgGif() :  await this.trendingGif();
        });
      };

    playGif = (gifUrl, previewUrl) => {
          this.setState({playGif:true,gifImageUrl:gifUrl,gifImageUrlPreview:previewUrl})
      }

    closePlayingGif = () => {
          this.setState({playGif:false});
      }

    render(){
        return (
        <div>
        {!this.state.playGif ?
        <div className={"container"}>
        <form className={'serach-from'} onSubmit={this.handleSearchSubmit} autoComplete={'on'}>
        <label>
          <input placeholder="Search for Gif" type="text" value={this.state.serachValue} onChange={this.handleSearchValueChange} />
        </label>
        <input  className={'search'} type="submit" value="Search" />
      </form>
        {this.state.isSearching ? <div className={'header-text'}><p>Search results for : {this.state.serachValue}</p></div> : <div className={'header-text'}><p>Trending Gifs:</p></div>}
      <div>
          <ThumbnailGrid playGif = {this.playGif} data={this.state.data}/>
      </div>
      <ReactPaginate
          previousLabel={'previous'}
          nextLabel={'next'}
          breakLabel={'...'}
          breakClassName={'break-me'}
          pageCount={this.state.pageCount}
          marginPagesDisplayed={2}
          pageRangeDisplayed={10}
          onPageChange={this.handlePageClick}
          containerClassName={'pagination'}
          subContainerClassName={'pages pagination'}
          activeClassName={'active'}
        />
        </div>
        : 
        <div className={'gif-preview-container'}>
            <div className={'gif-preview'}>
            <div className={'go-back'} onClick={this.closePlayingGif}><button>Go Back</button></div>
            <div class={"image-container"}>
            <img  className={'gif-preview-img1'} width="50%" height="50%" src={this.state.gifImageUrlPreview}></img>
            <img className={'gif-preview-img2'} width="50%" height="50%" src={this.state.gifImageUrl}></img>
            </div>
            </div>
        </div>
        }
      </div>
        );
    }
}

export default Home;

