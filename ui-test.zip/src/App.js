import React from 'react';
import logo from './logo.svg';
import './App.css';
import './components/home';
import Home from './components/home';
function App() {
  return (
    <div className="App">
      <div className="app-name">Gipphy</div>
     <Home/>
    </div>
  );
}

export default App;
